/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cs355;

import java.awt.Graphics2D;

/**
 *
 * @author Talonos
 */
public interface ViewRefresher 
{
    void refreshView(Graphics2D g2d);
}
