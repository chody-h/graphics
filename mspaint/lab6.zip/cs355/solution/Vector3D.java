package cs355.solution;

public class Vector3D {

	double v1 = 0;
	double v2 = 0;
	double v3 = 0;
	double v4 = 0;
	
	public Vector3D(double v1, double v2, double v3, double v4) {
		this.v1 = v1;
		this.v2 = v2;
		this.v3 = v3;
		this.v4 = v4;
	}

}
