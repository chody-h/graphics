package cs355.model;

import java.awt.Color;
import java.awt.Point;

public class MyRectangle extends MyShape {
//	location of upper left corner, height, width, & accessors
	private Point tl;
	private int w;
	private int h;
	
	public MyRectangle(Color color, Point topLeft) {
		// topleft and center are equivalent when the rectangle is created
		super(color, topLeft);
		tl = topLeft;
		w = 0;
		h = 0;
	}
	
	public void Update(Point topLeft, int width, int height) {
		int x = topLeft.x + width/2;
		int y = topLeft.y + height/2;
		Point center = new Point(x, y);
		SetCenter(center);

		tl = topLeft;
		w = width;
		h = height;
	}

	public void SetTopLeft(Point topLeft) {
		tl = topLeft;
	}

	public void SetWidth(int width) {
		w = width;
	}

	public void SetHeight(int height) {
		h = height;
	}
	
	public Point GetTopLeft() {
		return tl;
	}
	
	public int GetWidth() {
		return w;
	}
	
	public int GetHeight() {
		return h;
	}
}
