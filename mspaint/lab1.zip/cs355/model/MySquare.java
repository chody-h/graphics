package cs355.model;

import java.awt.Color;
import java.awt.Point;

public class MySquare extends MyShape {
//	location of upper left corner and length of a side & accessors
	private Point tl;
	private int l;
	
	public MySquare(Color color, Point topLeft) {
		// topLeft and center are equivalent when a square is created
		super(color, topLeft);
		tl = topLeft;
		l = 0;
	}
	
	public void Update(Point topLeft, int length) {
		int x = topLeft.x + length/2;
		int y = topLeft.y + length/2;
		Point center = new Point(x, y);
		SetCenter(center);

		tl = topLeft;
		l = length;
	}

	public void SetTopLeft(Point topLeft) {
		tl = topLeft;
	}

	public void SetLength(int length) {
		l = length;
	}
	
	public Point GetTopLeft() {
		return tl;
	}
	
	public int GetLength() {
		return l;
	}
}
